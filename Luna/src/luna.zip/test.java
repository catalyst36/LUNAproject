package luna;

public class test {

	public static void main(String[] args) {
		pageScreen ps = new pageScreen();
		ps.pagescreen();
		

	}

}
